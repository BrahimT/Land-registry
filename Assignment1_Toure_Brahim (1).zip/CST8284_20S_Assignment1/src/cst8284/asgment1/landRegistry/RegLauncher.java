package cst8284.asgment1.landRegistry;

/* 
 * Course Name:CST8284
 * Student Name:Brahim Toure
 * Class name: RegLauncher
 * Date:6/22/2020
*/
public class RegLauncher {

	public static void main(String[] args) {

		new RegView().launch();
	}
}
